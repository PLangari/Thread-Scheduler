#define _XOPEN_SOURCE 600
#include "sut.h"
#include <stdio.h>
#include <stdlib.h>
#include <ucontext.h>
#include <stdbool.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#include "queue/queue.h"

#define STACK_SIZE 1024*1024

pthread_t *cexec, *iexec;
int *arr;

// ready queue and wait queue
struct queue rq, wq;

// ready queue lock and wait queue lock, and teardown
pthread_mutex_t *mutex_wq, *mutex_rq, *mutex_td;

// flag (only used once) to terminate program
bool teardown = false;

// ucp for cexec and iexec
ucontext_t *ucpe, *ucpi;

// pointer to a void function that takes int as arg
typedef void (*sut_task_f)();


bool get_teardown_flag() {
    bool flag_value;
    pthread_mutex_lock(mutex_td);
    flag_value = teardown;
    pthread_mutex_unlock(mutex_td);
    return flag_value;
}

/**
 * @brief Creates an additional iexec executor (pthread). The executor continuously
 * checks if there's a I/O thread to run: if there's one, it runs it; otherwise, pauses
 * for a short time.
 * @return void* 
 */
void *iexec_thread()
{
    while (!get_teardown_flag())
    {
        // first checks if the wait q is empty or not
        pthread_mutex_lock(mutex_wq);
        struct queue_entry *top = queue_peek_front(&wq);
        pthread_mutex_unlock(mutex_wq);

        if (top != NULL) {
            // get the ucontext_t from the entry
            ucontext_t *ucp = (ucontext_t *)top->data;

            // swap the context
            if (swapcontext(ucpi, ucp) == -1)
            {
                perror("swapcontext");
                exit(EXIT_FAILURE);
            };

            // thread no longer running: omit it
            pthread_mutex_lock(mutex_wq);
            top = queue_pop_head(&wq);
            pthread_mutex_unlock(mutex_wq);

            free(top->data);
            free(top);            
        } else {
            // sleep 100ms if there's no tasks currently
            usleep(100000);
        }
    }
}

/**
 * @brief Similar to cexec_thread(): continuously checks if there's a task in ready queue to run
 * 
 */
void cexec_thread()
{
    while (!get_teardown_flag())
    {
        // first checks if the wait q is empty or not
        pthread_mutex_lock(mutex_rq);
        struct queue_entry *top = queue_peek_front(&rq);
        pthread_mutex_unlock(mutex_rq);

        if (top != NULL) {
            // get the ucontext_t from the entry
            ucontext_t *ucp = (ucontext_t *)top->data;

            // swap the context
            if (swapcontext(ucpe, ucp) == -1)
            {
                perror("swapcontext");
                exit(EXIT_FAILURE);
            };

            // thread no longer running: omit it
            pthread_mutex_lock(mutex_rq);
            top = queue_pop_head(&rq);
            pthread_mutex_unlock(mutex_rq);

            free(top->data);
            free(top);
        } else {
            // sleep 100ms if there's no tasks currently
            usleep(100000);
        }
    }
}

void sut_init()
{
    // create the ready queue
    rq = queue_create();
    queue_init(&rq);

    // create the wait queue
    wq = queue_create();
    queue_init(&wq);

    // initialize locks for queues
    pthread_mutex_init(mutex_rq);
    pthread_mutex_init(mutex_wq);

    // create the iexec thread and let it run
    iexec = (pthread_t *)malloc(sizeof(pthread_t));
    pthread_create(iexec, NULL, iexec_thread, NULL);

    // current thread is set to cexec: let it run as it should
    cexec = (pthread_t *)malloc(sizeof(pthread_t));
    pthread_create(cexec, NULL, cexec_thread, NULL);
}


bool sut_create(sut_task_f fn) {
    if (get_teardown_flag()) return false;
    
    // create + allocate memory for thread
    ucontext_t *ucp = (ucontext_t *)malloc(sizeof(ucontext_t));
    // get current context for method
    if (getcontext(ucp) == 0) {
        // initialize default config for thread
        ucp->uc_stack.ss_sp = malloc(STACK_SIZE); 
        ucp->uc_stack.ss_size = STACK_SIZE;
        ucp->uc_stack.ss_flags = 0;

        // always come back to exec once the thread is done
        ucp->uc_link = &ucpe;

        makecontext(ucp, fn, 0);

        // create node for u_context and add it to the ready queue (requires lock/unlock)
        struct queue_entry *entry = queue_new_node(ucp);
        pthread_mutex_lock(mutex_rq);
        queue_insert_tail(&rq, entry);
        pthread_mutex_unlock(mutex_rq);

        return true;
    } else {
        perror("getcontext");
        return false;
    }
}


void sut_yield() {
    // lock the ready queue
    pthread_mutex_lock(mutex_rq);

    // get current operation : top of ready queue
    struct queue_entry *top = queue_pop_head(&rq);
    
    // Save the current context and make a new node out of it
    ucontext_t *current_context;
    getcontext(current_context);
    struct queue_entry *entry = queue_new_node(current_context);

    // add the current context to the back of ready queue
    queue_insert_tail(&rq, entry);

    // unlock the ready queue
    pthread_mutex_unlock(mutex_rq);

    // swap the context to main thread but with cexec_thread as the function
    makecontext(ucpe, cexec_thread, 0);
    setcontext(ucpe);
}

void sut_exit() {
    // lock the ready queue
    pthread_mutex_lock(mutex_rq);

    // get current operation : top of ready queue
    struct queue_entry *top = queue_pop_head(&rq);

    // unlock the ready queue
    pthread_mutex_unlock(mutex_rq);

    // swap the context to main thread but with cexec_thread as the function
    makecontext(ucpe, cexec_thread, 0);
    setcontext(ucpe);
};

int sut_open(char *file_name);
void sut_close(int fd);

void sut_write(int fd, char *buf, int size);
char *sut_read(int fd, char *buf, int size);


void sut_shutdown() {
    // clean up both queues
    pthread_mutex_lock(mutex_td);
    teardown = true;
    pthread_mutex_unlock(mutex_td);
};